<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'ghxYoVANcWYopuSvlxIZgPv6H');  // CONSUMER_KEY_HERE
    define('CONSUMER_SECRET', 'zC22J5Rp8xQODFUAYB87VpViinlnDih7kNFsSvmKKlwWBj09SE'); // CONSUMER_SECRET_HERE

    // User Access Token
    define('ACCESS_TOKEN', '4327730363-oN4qCCWi69hFtGRzvhQqgTJr0OdFX5esoGdBx3v'); // ACCESS_TOKEN_HERE
    define('ACCESS_SECRET', 'HJ7xYoEK3EY1Wu6PRr3cflijzZiMMR6MCr5865wxXKc1U'); // ACCESS_SECRET_HERE