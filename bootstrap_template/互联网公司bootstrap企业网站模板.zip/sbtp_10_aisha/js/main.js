(function ($) {
	"use strict";

    jQuery(window).load(function(){

        // Preloader
        $("#preloader").fadeOut(500);

    });


}(jQuery));